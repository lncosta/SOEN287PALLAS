<section class="navbarsection">
    <!--NavBar-->
    <div class="interiornav">
        <ul class="navigation" id="navmenu">
            <li class="item">
                <a class="link" href="mainpage.php"><span class="navbar-brand">PALLAS</span></a>
            </li>
            <li class="item">
                <a class="link" href="aboutpage.php">About</a>
            </li>
            <li class="item">
                <a class="link" href="performancearchive.php">Performance Gallery</a>
            </li>
            <li class="item">
                <a class="link" href="contactform.php">Contact + Booking</a>
            </li>
            <li class="item">
                <a class="link" href="ticketsales.php">Upcoming Performances</a>
            </li>
            <li class="item">
                <a class="link" href="faq.php">FAQ</a>
            </li>
            <li class="item">
                <a class="link" href="userpage.php">User's Page</a>
            </li>
        </ul>
    </div>
</section>