SOEN 287 Group Project
Section Q - Fall 2020
Team 8 - PALLAS Entertainment

Team members:
        Florian Charreau (26494889) 
        Piyush Goyal(40106759) 
        Aline Kurkdjian (40131528)
        Joseph Mezzacappa(40134799)
        Luiza Nogueira Costa (40124771)
        Yi Heng Yan (40060587)

Our goal was to create a business website for an event entertaiment group called PALLAS Entertainment. PALLAS offers different performers and entertainment services which can be booked by a visitor, as  well as a ticket marketplace where access to performances booked through PALLAS can be sold. 

For example, a client who wishes to hire a musician to play at their wedding can book this service with PALLAS. Another client, who is organizing a festival, can hire a MC for one of their stages and decide to add tickets for sale on the PALLAS platform, for their convinience. 


The website includes the following main functionalities:
- A main page that showcases the PALLAS brand, highlighted reviews, and special discounts.
- An about page containing a bit of a backstory for the artists.
- A performance gallery showing images and videos of previous performances, as well as client reviews of those events.
- A “contact me” page  with the client’s business information and a quote estimation form. The user can book an event through email or go directly to the checkout page and get a discount. 
- A ticket sales page where users who have booked public events can put tickets for sale and other users can purchase them.
- A FAQ page.
- A checkout page for ticket sales and for booked events. 
- A login system to view purchased tickets and bookings, add tickets for sale, obtain personalized discounts, and add reviews. If the user forgot their password, a new one will be sent to their registered email, and they can later reset it from their user page. 
- Email confirmation for all booking, registration, and purchases. 

This project was created using a XAMPP stack, mySQL database, and developed primarily for Chrome browsers. 

The "demo" database has been included with this submission and can be imported to the phpmyadmin of the server machine. 

This website uses a mixture of the "send mail from localhost" and PHPMailer functionalities, depending on the degree of complexity of the submission. 

WARNING! If the confirmation emails are not being sent, please verify your firewall protocols. You might need to change the PHPMailer protocol from isMail() to "$mail -> isSMTP();" in "MailTest.php" and "mailbookingpayment.php". This would vary among our group's computers, so please look out for this error. 

Please ensure that the mailing functionality of the server is set up with an email that accepts third-party access. A tutorial can be found here "https://meetanshi.com/blog/send-mail-from-localhost-xampp-using-gmail/". 
